clc,close all,clear all;
addpath('Results');
load ('InteractingNonStationaryGrowth50particle_16dimension_1tracks_1runs_with_regularization_10timesteps_init_dist_gaussian_init_state_0__PFPF_LEDH.mat');
for ii = 1: 10
 load(['Particle_LEDH_' num2str(ii) '.mat']);
 h=figure,scatter(new_particles(1,:),new_particles(2,:));
 hold on 
 scatter(ps.x_all{1, 1}(1,ii),ps.x_all{1, 1}(2,ii),250,'r*');
 hold on 
 scatter(output{1, 1}.PFPF_LEDH.x_est(1,ii), output{1, 1}.PFPF_LEDH.x_est(2,ii),250,'g*')
 title(strcat('time=',num2str(ii),',green=true, red=estimated,PFPF(LEDH)'));
 saveas(h,strcat('time=',num2str(ii),',PFPF(LEDH)'),'png');
end