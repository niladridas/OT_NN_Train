clc,close all,clear all;
addpath('Results');
load ('InteractingNonStationaryGrowth50particle_16dimension_1tracks_1runs_with_regularization_10timesteps_init_dist_gaussian_init_state_0__PFPF_GMM_LEDH.mat');
for ii = 1: 10
 load(['Particle_GSF_IPF_' num2str(ii) '.mat']);
 new_particles = reshape(new_particles,size(new_particles,1),size(new_particles,2)*size(new_particles,3));
 h=figure,scatter(new_particles(1,:),new_particles(2,:));
 hold on 
 scatter(ps.x_all{1, 1}(1,ii),ps.x_all{1, 1}(2,ii),250,'r*');
 hold on 
 scatter(output{1, 1}.PFPF_GMM_LEDH.x_est(1,ii), output{1, 1}.PFPF_GMM_LEDH.x_est(2,ii),250,'g*')
 title(strcat('time=',num2str(ii),',green=true, red=estimated,GSF-IPF(LEDH)'));
 saveas(h,strcat('time=',num2str(ii),',GSF-IPF(LEDH)'),'png');
end